"""Urbcart URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
#from website import urls
from website import views
urlpatterns = [
    path('admin/', admin.site.urls, name='admin'),
    path('home', views.under_constuction, name='home'),
    path('index', views.index, name='index'),
    path('my-account', views.my_account, name='my-account'),
    path('login-register', views.login_register, name='login-register'),
    path('about-us', views.about_us, name='about-us'),
    path('blog-details-audio', views.blog_details_audio, name='blog-details-audio'),
    path('blog-details-image', views.blog_details_image, name='blog-details-image'),
    path('blog-details-left-sidebar', views.blog_details_left_sidebar,
         name='blog-details-left-sidebar'),
    path('contact-us', views.contact_us, name='contact-us'),
    path('blog-details', views.blog_details, name='blog-details')
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
