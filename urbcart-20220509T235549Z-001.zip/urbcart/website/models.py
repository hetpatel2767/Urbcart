from django.db import models

# Create your models here.


class Contact(models.Model):
    first_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    email_address = models.CharField(max_length=254)
    contact_subject = models.TextField()
    message = models.TextField()
    date = models.DateField()

    def __str__(self) -> str:
        return self.first_name
