from django.shortcuts import render, redirect
from django.http import HttpResponse, request
from django.conf import settings
from datetime import datetime
from website.models import Contact
from django.contrib import messages
# Create your views here.


def under_constuction(request):
    return render(request, 'under_constuction.html')


def index(request):
    return render(request, 'index-3.html')


def my_account(request):
    return render(request, 'my-account.html')


def login_register(request):
    return render(request, 'login-register.html')


def about_us(request):
    return render(request, 'about-us.html')


def blog_details_audio(request):
    return render(request, 'blog-details-audio.html')


def blog_details_image(request):
    return render(request, 'blog-details-image.html')


def blog_details_left_sidebar(request):
    return render(request, 'blog-details-left-sidebar.html')


def blog_details(request):
    return render(request, 'blog-details.html')


def contact_us(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        phone = request.POST.get('phone')
        email_address = request.POST.get('email_address')
        contact_subject = request.POST.get('contact_subject')
        message = request.POST.get('message')
        contact = Contact(first_name=first_name, phone=phone, email_address=email_address,
                          contact_subject=contact_subject, message=message, date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent   ')
    return render(request, 'contact-us.html')
